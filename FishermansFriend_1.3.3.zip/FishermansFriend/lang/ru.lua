--Big thanks to Aspect for translating this to russian!
SafeAddString(FISHERMANSFRIEND_LAKE_FISHING_HOLE, "Место для рыбалки на озере",	0)
SafeAddString(FISHERMANSFRIEND_SALT_FISHING_HOLE, "Место для рыбалки на море", 	0)
SafeAddString(FISHERMANSFRIEND_MYST_FISHING_HOLE, "Место для рыбалки (мистическая вода)",0)
SafeAddString(FISHERMANSFRIEND_FOUL_FISHING_HOLE, "Место для рыбалки в сточной воде", 0)
SafeAddString(FISHERMANSFRIEND_OILY_FISHING_HOLE, "Место для рыбалки (маслянистая вода)", 	0)
SafeAddString(FISHERMANSFRIEND_RIVR_FISHING_HOLE, "Место для рыбалки на реке", 0)

SafeAddString(FISHERMANSFRIEND_CNF_DESCRIPTION, "Вы можете выбрать, хотите или нет сперва использовать альтернативные наживки (Пузанок, Голавль, Рыбная икра, Пескарь) вместо обычных (Черви, Кишки, Части насекомых, Личинки).", 0)
SafeAddString(FISHERMANSFRIEND_CNF_SET, "Сперва использовать альтернативные наживки:", 0)
SafeAddString(FISHERMANSFRIEND_CNF_MSG, "Сообщать, если нет подходящей наживки:")
SafeAddString(FISHERMANSFRIEND_NO_BAIT, "Нет подходящей наживки!", 0)
SafeAddString(FISHERMANSFRIEND_NO_BAIT_RST, "Зажмите для выбора наживки", 1)