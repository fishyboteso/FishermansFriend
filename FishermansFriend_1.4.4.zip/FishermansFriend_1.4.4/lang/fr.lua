--Big thanks to Frackou for translating this to french!
SafeAddString(FISHERMANSFRIEND_LAKE_FISHING_HOLE, "Trou de pêche lacustre", 0)
SafeAddString(FISHERMANSFRIEND_SALT_FISHING_HOLE, "Trou de pêche d'eau de mer", 0)
SafeAddString(FISHERMANSFRIEND_MYST_FISHING_HOLE, "Trou de pêche mystique",0)
SafeAddString(FISHERMANSFRIEND_FOUL_FISHING_HOLE, "Trou de pêche sale", 0)
SafeAddString(FISHERMANSFRIEND_OILY_FISHING_HOLE, "Trou de pêche huileux", 0)
SafeAddString(FISHERMANSFRIEND_RIVR_FISHING_HOLE, "Trou de pêche de rivière", 0)

SafeAddString(FISHERMANSFRIEND_CNF_DESCRIPTION, "Fisherman's Friend permet d'équiper automatiquement l'appât approprié lorsque vous regardez un trou de pêche et d'en changer lorsque vous manquez d'un type. Ci-dessous, vous pouvez choisir si vous souhaitez ou non utiliser d'abord les appâts alternatifs (Shad, Chevesne, Œufs de poisson et Méné) plutôt que les appâts ordinaires (Morceaux d'insectes, Vers, Rampants, Entrailles) ainsi qu'afficher un message vous indiquant que vous n'avez pas l'appât approprié dans votre sac.", 0)
SafeAddString(FISHERMANSFRIEND_CNF_SET, "Utiliser un appât de meilleur qualité en premier:", 0)
SafeAddString(FISHERMANSFRIEND_CNF_MSG, "Indiquer si vous n'avez pas l'appât approprié:")
SafeAddString(FISHERMANSFRIEND_NO_BAIT, "L'appât approprié n'est pas disponible dans votre sac!", 0)
SafeAddString(FISHERMANSFRIEND_NO_BAIT_RST, "Maintenir pour sélectionner un appât", 1)